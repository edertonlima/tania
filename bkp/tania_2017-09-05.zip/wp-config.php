<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tania');

/** MySQL database username */
define('DB_USER', 'tania');

/** MySQL database password */
define('DB_PASSWORD', 'pPeNeYAleLMIvtbq');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'mu_P3Y~Ff(Z|d#@woC ViWH<Rdhc8^?rP^6l~71RO5[k@6Wl5}MExQR+jg,~lB1U');
define('SECURE_AUTH_KEY',  'g-.T3IK.cC,8|UNuLc<eAY=Z(HTU/%Dma?{ok[YYsMB~#b1~Z@hXY0vD,4!e+uJ#');
define('LOGGED_IN_KEY',    'M3Wls1~D>E4;&5*F=z%ym-_93c<lRIM_x+^gu8k]uDImO-<=Lr@~Y)J:t,(&Fk8u');
define('NONCE_KEY',        'fos3*Yt48z0Cn; p5]p8bL0]V!2Iti%(mR1UZ^G.}0zS~IQt^i:^aTW|n)RmV!r9');
define('AUTH_SALT',        '0xg;fTY~+t,I%~>?rs|=P:d2T01qxkp<`ny/-,P78c((a%3z]CA@ZW{=m!f287k=');
define('SECURE_AUTH_SALT', 'CPZb.J?rJ!,XD3~L*>#d8Nsc)A.RAX6+;aB&hTl_H)9|Yq*ET_|0Ekx2oY`BAL:x');
define('LOGGED_IN_SALT',   '?s!xe.[*SejxQ]X26<UUC?6i8 =TUc+uNJ}NnKj+1/66zwR2B&6sgvMyg7,`.e2p');
define('NONCE_SALT',       'ccnoe=nm1xxL`E( ez#kB&(*t`dOn<{*|Xi%*{:sCKo,X|/xP:MCvj2DR66%?f<m');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
